import { expect, test, type Page } from '@playwright/test'

type RuntimeDebug = { paused: boolean; pauseReason: string; journal: string[] }

/**
 * Pętla 120 Hz celowo przechodzi w pauzę, gdy klatka przekroczy limit
 * nadrabiania. Pod obciążeniem automatyzacji zdarza się to także tuż po
 * wznowieniu, dlatego wznawiamy do skutku i sprawdzamy, że powodem jest
 * wyłącznie ten udokumentowany mechanizm, a nie inny błąd stanu.
 */
async function resumeIfPaused(page: Page, attempts = 8): Promise<void> {
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    const state = await page.evaluate(() => (
      window as unknown as { __retroDebugSnapshot: () => RuntimeDebug }
    ).__retroDebugSnapshot())
    if (!state.paused) return
    if (attempt > 0) {
      expect(state.pauseReason).toBe('zbyt długa przerwa klatki')
    }
    await page.keyboard.press('Enter')
  }
}

test('shell działa klawiaturą, skaluje obraz i przeżywa odmowę API', async ({ page }) => {
  await page.addInitScript(() => {
    const state = { fullscreenCalls: 0, audioCalls: 0 }
    Object.defineProperty(window, '__apiTestState', { value: state })
    Element.prototype.requestFullscreen = () => {
      state.fullscreenCalls += 1
      return Promise.reject(new Error('celowa odmowa testowa'))
    }

    class RejectedAudioContext {
      state = 'suspended'
      resume() {
        state.audioCalls += 1
        return Promise.reject(new Error('celowa blokada audio'))
      }
    }
    Object.defineProperty(window, 'AudioContext', { value: RejectedAudioContext })
  })

  await page.setViewportSize({ width: 1280, height: 720 })
  await page.goto('/', { waitUntil: 'domcontentloaded' })

  const canvas = page.locator('#game-canvas')
  await expect(canvas).toHaveAttribute('width', '960')
  await expect(canvas).toHaveAttribute('height', '540')
  await expect(canvas).toHaveAttribute('aria-label', /ekran tytułowy/)
  await expect.poll(() => page.evaluate(() => ({
    scrollWidth: document.documentElement.scrollWidth,
    width: innerWidth,
    canvas: document.querySelector('canvas')?.getBoundingClientRect().toJSON(),
  }))).toMatchObject({
    scrollWidth: 1280,
    width: 1280,
    canvas: { width: 1280, height: 720 },
  })
  await page.screenshot({ path: 'docs/evidence/PKG-007/browser-artifacts/regression-title-1280x720.png' })

  await page.keyboard.press('Enter')
  await expect.poll(() => page.evaluate(() => ({
    api: (window as unknown as { __apiTestState: { fullscreenCalls: number; audioCalls: number } }).__apiTestState,
    debug: (window as unknown as { __retroDebugSnapshot: () => { screen: string; paused: boolean } }).__retroDebugSnapshot(),
  }))).toMatchObject({
    api: { fullscreenCalls: 1, audioCalls: 1 },
    debug: { screen: 'menu' },
  })
  await resumeIfPaused(page)
  await expect(canvas).toHaveAttribute('aria-label', /menu główne/)

  await page.keyboard.press('f')
  await expect.poll(() => page.evaluate(() => (
    window as unknown as { __apiTestState: { fullscreenCalls: number } }
  ).__apiTestState.fullscreenCalls)).toBe(2)

  await resumeIfPaused(page)
  await page.keyboard.press('p')
  await expect(canvas).toHaveAttribute('aria-label', /pauza/)
  const pausedTick = await page.evaluate(() => (
    window as unknown as { __retroDebugSnapshot: () => { tick: number } }
  ).__retroDebugSnapshot().tick)
  await page.waitForTimeout(80)
  expect(await page.evaluate(() => (
    window as unknown as { __retroDebugSnapshot: () => { tick: number } }
  ).__retroDebugSnapshot().tick)).toBe(pausedTick)
  await resumeIfPaused(page)
  await expect(canvas).toHaveAttribute('aria-label', /menu główne/)

  await page.screenshot({ path: 'docs/evidence/PKG-007/browser-artifacts/regression-menu-1280x720.png' })
  await page.setViewportSize({ width: 1920, height: 1080 })
  await expect.poll(() => page.evaluate(() => document.querySelector('canvas')?.getBoundingClientRect().toJSON())).toMatchObject({
    width: 1920,
    height: 1080,
  })
  await page.screenshot({ path: 'docs/evidence/PKG-007/browser-artifacts/regression-menu-1920x1080.png' })

  await page.evaluate(() => {
    Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => 'hidden' })
    document.dispatchEvent(new Event('visibilitychange'))
  })
  await expect(canvas).toHaveAttribute('aria-label', /pauza/)
  // Powrót do karty jest częścią scenariusza: przy dokumencie trwale `hidden`
  // przeglądarka dławi rAF, więc pętla wpadałaby w udokumentowaną auto-pauzę.
  await page.evaluate(() => {
    Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => 'visible' })
    document.dispatchEvent(new Event('visibilitychange'))
  })
  await resumeIfPaused(page)
  await expect(canvas).toHaveAttribute('aria-label', /menu główne/)

  await page.evaluate(() => window.dispatchEvent(new Event('blur')))
  await expect(canvas).toHaveAttribute('aria-label', /pauza/)
})
